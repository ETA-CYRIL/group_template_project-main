package sample;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class StudyModule implements Module {

    public JSONArray possibleAttainmentLanguages;
    public JSONObject metadata;
    public String code;
    public String studyRightSelectionType;
    public String groupId;
    public JSONArray searchTags;
    public JSONArray universityOrgIds;
    public JSONObject rule;
    public String studyLevel;
    public String type;
    public boolean moduleContentApprovalRequired;
    public JSONObject validityPeriod;
    public String prerequisites;
    public JSONArray organisations;
    public String substitutions;
    public JSONObject contentDescription;
    public JSONObject outcomes;
    public String additionalInfo;
    public JSONObject tweetText;
    public boolean graded;
    public String id;
    public JSONArray studyFields;
    public String cooperationNetworkStatus;
    public String inclusionApplicationInstruction;
    public String approvalState;
    public JSONObject targetCredits;
    public String abbreviation;
    public String minorStudyRightApplicationInstructions;
    public String documentState;
    public String contentFilter;
    public JSONObject customCodeUrns;
    public String minorStudyRightAcceptanceType;
    public JSONArray responsibilityInfos;
    public JSONObject name;
    public String gradeScaleId;
    public String cooperationNetworkIds;
    public JSONArray curriculumPeriodIds;

    public StudyModule(JSONArray possibleAttainmentLanguages, JSONObject metadata, String code, String studyRightSelectionType, String groupId, JSONArray searchTags, JSONArray universityOrgIds, JSONObject rule, String studyLevel, String type, boolean moduleContentApprovalRequired, JSONObject validityPeriod, String prerequisites, JSONArray organisations, String substitutions, JSONObject contentDescription, JSONObject outcomes, String additionalInfo, JSONObject tweetText, boolean graded, String id, JSONArray studyFields, String cooperationNetworkStatus, String inclusionApplicationInstruction, String approvalState, JSONObject targetCredits, String abbreviation, String minorStudyRightApplicationInstructions, String documentState, String contentFilter, JSONObject customCodeUrns, String minorStudyRightAcceptanceType, JSONArray responsibilityInfos, JSONObject name, String gradeScaleId, String cooperationNetworkIds, JSONArray curriculumPeriodIds) {
        this.possibleAttainmentLanguages = possibleAttainmentLanguages;
        this.metadata = metadata;
        this.code = code;
        this.studyRightSelectionType = studyRightSelectionType;
        this.groupId = groupId;
        this.searchTags = searchTags;
        this.universityOrgIds = universityOrgIds;
        this.rule = rule;
        this.studyLevel = studyLevel;
        this.type = type;
        this.moduleContentApprovalRequired = moduleContentApprovalRequired;
        this.validityPeriod = validityPeriod;
        this.prerequisites = prerequisites;
        this.organisations = organisations;
        this.substitutions = substitutions;
        this.contentDescription = contentDescription;
        this.outcomes = outcomes;
        this.additionalInfo = additionalInfo;
        this.tweetText = tweetText;
        this.graded = graded;
        this.id = id;
        this.studyFields = studyFields;
        this.cooperationNetworkStatus = cooperationNetworkStatus;
        this.inclusionApplicationInstruction = inclusionApplicationInstruction;
        this.approvalState = approvalState;
        this.targetCredits = targetCredits;
        this.abbreviation = abbreviation;
        this.minorStudyRightApplicationInstructions = minorStudyRightApplicationInstructions;
        this.documentState = documentState;
        this.contentFilter = contentFilter;
        this.customCodeUrns = customCodeUrns;
        this.minorStudyRightAcceptanceType = minorStudyRightAcceptanceType;
        this.responsibilityInfos = responsibilityInfos;
        this.name = name;
        this.gradeScaleId = gradeScaleId;
        this.cooperationNetworkIds = cooperationNetworkIds;
        this.curriculumPeriodIds = curriculumPeriodIds;
    }

    public JSONArray getPossibleAttainmentLanguages() {
        return possibleAttainmentLanguages;
    }

    public void setPossibleAttainmentLanguages(JSONArray possibleAttainmentLanguages) {
        this.possibleAttainmentLanguages = possibleAttainmentLanguages;
    }

    public JSONObject getMetadata() {
        return metadata;
    }

    public void setMetadata(JSONObject metadata) {
        this.metadata = metadata;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getStudyRightSelectionType() {
        return studyRightSelectionType;
    }

    public void setStudyRightSelectionType(String studyRightSelectionType) {
        this.studyRightSelectionType = studyRightSelectionType;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public JSONArray getSearchTags() {
        return searchTags;
    }

    public void setSearchTags(JSONArray searchTags) {
        this.searchTags = searchTags;
    }

    public JSONArray getUniversityOrgIds() {
        return universityOrgIds;
    }

    public void setUniversityOrgIds(JSONArray universityOrgIds) {
        this.universityOrgIds = universityOrgIds;
    }

    public JSONObject getRule() {
        return rule;
    }

    public void setRule(JSONObject rule) {
        this.rule = rule;
    }

    public String getStudyLevel() {
        return studyLevel;
    }

    public void setStudyLevel(String studyLevel) {
        this.studyLevel = studyLevel;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isModuleContentApprovalRequired() {
        return moduleContentApprovalRequired;
    }

    public void setModuleContentApprovalRequired(boolean moduleContentApprovalRequired) {
        this.moduleContentApprovalRequired = moduleContentApprovalRequired;
    }

    public JSONObject getValidityPeriod() {
        return validityPeriod;
    }

    public void setValidityPeriod(JSONObject validityPeriod) {
        this.validityPeriod = validityPeriod;
    }

    public String getPrerequisites() {
        return prerequisites;
    }

    public void setPrerequisites(String prerequisites) {
        this.prerequisites = prerequisites;
    }

    public JSONArray getOrganisations() {
        return organisations;
    }

    public void setOrganisations(JSONArray organisations) {
        this.organisations = organisations;
    }

    public String getSubstitutions() {
        return substitutions;
    }

    public void setSubstitutions(String substitutions) {
        this.substitutions = substitutions;
    }

    public JSONObject getContentDescription() {
        return contentDescription;
    }

    public void setContentDescription(JSONObject contentDescription) {
        this.contentDescription = contentDescription;
    }

    public JSONObject getOutcomes() {
        return outcomes;
    }

    public void setOutcomes(JSONObject outcomes) {
        this.outcomes = outcomes;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public JSONObject getTweetText() {
        return tweetText;
    }

    public void setTweetText(JSONObject tweetText) {
        this.tweetText = tweetText;
    }

    public boolean isGraded() {
        return graded;
    }

    public void setGraded(boolean graded) {
        this.graded = graded;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public JSONArray getStudyFields() {
        return studyFields;
    }

    public void setStudyFields(JSONArray studyFields) {
        this.studyFields = studyFields;
    }

    public String getCooperationNetworkStatus() {
        return cooperationNetworkStatus;
    }

    public void setCooperationNetworkStatus(String cooperationNetworkStatus) {
        this.cooperationNetworkStatus = cooperationNetworkStatus;
    }

    public String getInclusionApplicationInstruction() {
        return inclusionApplicationInstruction;
    }

    public void setInclusionApplicationInstruction(String inclusionApplicationInstruction) {
        this.inclusionApplicationInstruction = inclusionApplicationInstruction;
    }

    public String getApprovalState() {
        return approvalState;
    }

    public void setApprovalState(String approvalState) {
        this.approvalState = approvalState;
    }

    public JSONObject getTargetCredits() {
        return targetCredits;
    }

    public void setTargetCredits(JSONObject targetCredits) {
        this.targetCredits = targetCredits;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getMinorStudyRightApplicationInstructions() {
        return minorStudyRightApplicationInstructions;
    }

    public void setMinorStudyRightApplicationInstructions(String minorStudyRightApplicationInstructions) {
        this.minorStudyRightApplicationInstructions = minorStudyRightApplicationInstructions;
    }

    public String getDocumentState() {
        return documentState;
    }

    public void setDocumentState(String documentState) {
        this.documentState = documentState;
    }

    public String getContentFilter() {
        return contentFilter;
    }

    public void setContentFilter(String contentFilter) {
        this.contentFilter = contentFilter;
    }

    public JSONObject getCustomCodeUrns() {
        return customCodeUrns;
    }

    public void setCustomCodeUrns(JSONObject customCodeUrns) {
        this.customCodeUrns = customCodeUrns;
    }

    public String getMinorStudyRightAcceptanceType() {
        return minorStudyRightAcceptanceType;
    }

    public void setMinorStudyRightAcceptanceType(String minorStudyRightAcceptanceType) {
        this.minorStudyRightAcceptanceType = minorStudyRightAcceptanceType;
    }

    public JSONArray getResponsibilityInfos() {
        return responsibilityInfos;
    }

    public void setResponsibilityInfos(JSONArray responsibilityInfos) {
        this.responsibilityInfos = responsibilityInfos;
    }

    public JSONObject getName() {
        return name;
    }

    public void setName(JSONObject name) {
        this.name = name;
    }

    public String getGradeScaleId() {
        return gradeScaleId;
    }

    public void setGradeScaleId(String gradeScaleId) {
        this.gradeScaleId = gradeScaleId;
    }

    public String getCooperationNetworkIds() {
        return cooperationNetworkIds;
    }

    public void setCooperationNetworkIds(String cooperationNetworkIds) {
        this.cooperationNetworkIds = cooperationNetworkIds;
    }

    public JSONArray getCurriculumPeriodIds() {
        return curriculumPeriodIds;
    }

    public void setCurriculumPeriodIds(JSONArray curriculumPeriodIds) {
        this.curriculumPeriodIds = curriculumPeriodIds;
    }

}
