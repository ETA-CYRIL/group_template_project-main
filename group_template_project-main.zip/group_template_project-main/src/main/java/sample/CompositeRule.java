package sample;

import org.json.simple.JSONArray;

public class CompositeRule {

    public boolean allMandatory;
    public String description;
    public JSONArray rules;
    public String require;
    public String type;
    public String localId;

    public CompositeRule(boolean allMandatory, String description, JSONArray rules, String require, String type, String localId) {
        this.allMandatory = allMandatory;
        this.description = description;
        this.rules = rules;
        this.require = require;
        this.type = type;
        this.localId = localId;
    }

    public boolean isAllMandatory() {
        return allMandatory;
    }

    public void setAllMandatory(boolean allMandatory) {
        this.allMandatory = allMandatory;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public JSONArray getRules() {
        return rules;
    }

    public void setRules(JSONArray rules) {
        this.rules = rules;
    }

    public String getRequire() {
        return require;
    }

    public void setRequire(String require) {
        this.require = require;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLocalId() {
        return localId;
    }

    public void setLocalId(String localId) {
        this.localId = localId;
    }

}
