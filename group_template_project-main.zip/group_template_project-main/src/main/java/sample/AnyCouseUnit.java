package sample;

public class AnyCouseUnit {

    public String type;
    public String localId;

    public AnyCouseUnit(String type, String localId) {
        this.type = type;
        this.localId = localId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLocalId() {
        return localId;
    }

    public void setLocalId(String localId) {
        this.localId = localId;
    }

}
