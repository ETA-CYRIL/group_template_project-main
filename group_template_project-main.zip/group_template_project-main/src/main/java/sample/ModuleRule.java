package sample;

public class ModuleRule {

    public String type;
    public String moduleGroupId;
    public String localId;

    public ModuleRule(String type, String moduleGroupId, String localId) {
        this.type = type;
        this.moduleGroupId = moduleGroupId;
        this.localId = localId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getModuleGroupId() {
        return moduleGroupId;
    }

    public void setModuleGroupId(String moduleGroupId) {
        this.moduleGroupId = moduleGroupId;
    }

    public String getLocalId() {
        return localId;
    }

    public void setLocalId(String localId) {
        this.localId = localId;
    }

}
