package sample;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class DegreeProgramme implements Module {

    public JSONObject metadata;
    public String code;
    public String groupId;
    public JSONArray universityOrgIds;
    public JSONObject rule;
    public String type;
    public JSONArray degreeTitleUrns;
    public boolean moduleContentApprovalRequired;
    public JSONObject validityPeriod;
    public JSONArray organisations;
    public String contentDescription;
    public String additionalInfo;
    public String tweetText;
    public JSONObject learningOutcomes;
    public String id;
    public JSONArray studyFields;
    public String inclusionApplicationInstruction;
    public String degreeProgramTypeUrn;
    public String approvalState;
    public JSONArray educationLocationUrns;
    public JSONObject targetCredits;
    public JSONArray educationClassificationUrns;
    public String documentState;
    public JSONObject customCodeUrns;
    public String tuitionFee;
    public JSONArray degreeLanguageUrns;
    public  JSONArray responsibilityInfos;
    public JSONObject name;
    public String gradeScaleId;
    public JSONArray curriculumPeriodIds;

    public DegreeProgramme(JSONObject metadata, String code, String groupId, JSONArray universityOrgIds, JSONObject rule, String type, JSONArray degreeTitleUrns, boolean moduleContentApprovalRequired, JSONObject validityPeriod, JSONArray organisations, String contentDescription, String additionalInfo, String tweetText, JSONObject learningOutcomes, String id, JSONArray studyFields, String inclusionApplicationInstruction, String degreeProgramTypeUrn, String approvalState, JSONArray educationLocationUrns, JSONObject targetCredits, JSONArray educationClassificationUrns, String documentState, JSONObject customCodeUrns, String tuitionFee, JSONArray degreeLanguageUrns, JSONArray responsibilityInfos, JSONObject name, String gradeScaleId, JSONArray curriculumPeriodIds) {
        this.metadata = metadata;
        this.code = code;
        this.groupId = groupId;
        this.universityOrgIds = universityOrgIds;
        this.rule = rule;
        this.type = type;
        this.degreeTitleUrns = degreeTitleUrns;
        this.moduleContentApprovalRequired = moduleContentApprovalRequired;
        this.validityPeriod = validityPeriod;
        this.organisations = organisations;
        this.contentDescription = contentDescription;
        this.additionalInfo = additionalInfo;
        this.tweetText = tweetText;
        this.learningOutcomes = learningOutcomes;
        this.id = id;
        this.studyFields = studyFields;
        this.inclusionApplicationInstruction = inclusionApplicationInstruction;
        this.degreeProgramTypeUrn = degreeProgramTypeUrn;
        this.approvalState = approvalState;
        this.educationLocationUrns = educationLocationUrns;
        this.targetCredits = targetCredits;
        this.educationClassificationUrns = educationClassificationUrns;
        this.documentState = documentState;
        this.customCodeUrns = customCodeUrns;
        this.tuitionFee = tuitionFee;
        this.degreeLanguageUrns = degreeLanguageUrns;
        this.responsibilityInfos = responsibilityInfos;
        this.name = name;
        this.gradeScaleId = gradeScaleId;
        this.curriculumPeriodIds = curriculumPeriodIds;
    }

    public JSONObject getMetadata() {
        return metadata;
    }

    public void setMetadata(JSONObject metadata) {
        this.metadata = metadata;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public JSONArray getUniversityOrgIds() {
        return universityOrgIds;
    }

    public void setUniversityOrgIds(JSONArray universityOrgIds) {
        this.universityOrgIds = universityOrgIds;
    }

    public JSONObject getRule() {
        return rule;
    }

    public void setRule(JSONObject rule) {
        this.rule = rule;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public JSONArray getDegreeTitleUrns() {
        return degreeTitleUrns;
    }

    public void setDegreeTitleUrns(JSONArray degreeTitleUrns) {
        this.degreeTitleUrns = degreeTitleUrns;
    }

    public boolean isModuleContentApprovalRequired() {
        return moduleContentApprovalRequired;
    }

    public void setModuleContentApprovalRequired(boolean moduleContentApprovalRequired) {
        this.moduleContentApprovalRequired = moduleContentApprovalRequired;
    }

    public JSONObject getValidityPeriod() {
        return validityPeriod;
    }

    public void setValidityPeriod(JSONObject validityPeriod) {
        this.validityPeriod = validityPeriod;
    }

    public JSONArray getOrganisations() {
        return organisations;
    }

    public void setOrganisations(JSONArray organisations) {
        this.organisations = organisations;
    }

    public String getContentDescription() {
        return contentDescription;
    }

    public void setContentDescription(String contentDescription) {
        this.contentDescription = contentDescription;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getTweetText() {
        return tweetText;
    }

    public void setTweetText(String tweetText) {
        this.tweetText = tweetText;
    }

    public JSONObject getLearningOutcomes() {
        return learningOutcomes;
    }

    public void setLearningOutcomes(JSONObject learningOutcomes) {
        this.learningOutcomes = learningOutcomes;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public JSONArray getStudyFields() {
        return studyFields;
    }

    public void setStudyFields(JSONArray studyFields) {
        this.studyFields = studyFields;
    }

    public String getInclusionApplicationInstruction() {
        return inclusionApplicationInstruction;
    }

    public void setInclusionApplicationInstruction(String inclusionApplicationInstruction) {
        this.inclusionApplicationInstruction = inclusionApplicationInstruction;
    }

    public String getDegreeProgramTypeUrn() {
        return degreeProgramTypeUrn;
    }

    public void setDegreeProgramTypeUrn(String degreeProgramTypeUrn) {
        this.degreeProgramTypeUrn = degreeProgramTypeUrn;
    }

    public String getApprovalState() {
        return approvalState;
    }

    public void setApprovalState(String approvalState) {
        this.approvalState = approvalState;
    }

    public JSONArray getEducationLocationUrns() {
        return educationLocationUrns;
    }

    public void setEducationLocationUrns(JSONArray educationLocationUrns) {
        this.educationLocationUrns = educationLocationUrns;
    }

    public JSONObject getTargetCredits() {
        return targetCredits;
    }

    public void setTargetCredits(JSONObject targetCredits) {
        this.targetCredits = targetCredits;
    }

    public JSONArray getEducationClassificationUrns() {
        return educationClassificationUrns;
    }

    public void setEducationClassificationUrns(JSONArray educationClassificationUrns) {
        this.educationClassificationUrns = educationClassificationUrns;
    }

    public String getDocumentState() {
        return documentState;
    }

    public void setDocumentState(String documentState) {
        this.documentState = documentState;
    }

    public JSONObject getCustomCodeUrns() {
        return customCodeUrns;
    }

    public void setCustomCodeUrns(JSONObject customCodeUrns) {
        this.customCodeUrns = customCodeUrns;
    }

    public String getTuitionFee() {
        return tuitionFee;
    }

    public void setTuitionFee(String tuitionFee) {
        this.tuitionFee = tuitionFee;
    }

    public JSONArray getDegreeLanguageUrns() {
        return degreeLanguageUrns;
    }

    public void setDegreeLanguageUrns(JSONArray degreeLanguageUrns) {
        this.degreeLanguageUrns = degreeLanguageUrns;
    }

    public JSONArray getResponsibilityInfos() {
        return responsibilityInfos;
    }

    public void setResponsibilityInfos(JSONArray responsibilityInfos) {
        this.responsibilityInfos = responsibilityInfos;
    }

    public JSONObject getName() {
        return name;
    }

    public void setName(JSONObject name) {
        this.name = name;
    }

    public String getGradeScaleId() {
        return gradeScaleId;
    }

    public void setGradeScaleId(String gradeScaleId) {
        this.gradeScaleId = gradeScaleId;
    }

    public JSONArray getCurriculumPeriodIds() {
        return curriculumPeriodIds;
    }

    public void setCurriculumPeriodIds(JSONArray curriculumPeriodIds) {
        this.curriculumPeriodIds = curriculumPeriodIds;
    }

}
