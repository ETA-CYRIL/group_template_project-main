package sample;

import org.json.simple.JSONObject;

public class CreditsRule {

    public JSONObject credits;
    public JSONObject rule;
    public String type;
    public String localId;

    public CreditsRule(JSONObject credits, JSONObject rule, String type, String localId) {
        this.credits = credits;
        this.rule = rule;
        this.type = type;
        this.localId = localId;
    }

    public JSONObject getCredits() {
        return credits;
    }

    public void setCredits(JSONObject credits) {
        this.credits = credits;
    }

    public JSONObject getRule() {
        return rule;
    }

    public void setRule(JSONObject rule) {
        this.rule = rule;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLocalId() {
        return localId;
    }

    public void setLocalId(String localId) {
        this.localId = localId;
    }

}
