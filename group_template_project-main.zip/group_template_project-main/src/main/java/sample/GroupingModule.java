package sample;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class GroupingModule implements Module {

    public JSONObject metadata;
    public String code;
    public String groupId;
    public JSONObject name;
    public JSONArray universityOrgIds;
    public JSONObject rule;
    public String id;
    public String type;
    public String documentState;
    public JSONObject contentFilter;
    public boolean moduleContentApprovalRequired;
    public JSONArray curriculumPeriodIds;

    public GroupingModule(JSONObject metadata, String code, String groupId, JSONObject name, JSONArray universityOrgIds, JSONObject rule, String id, String type, String documentState, JSONObject contentFilter, boolean moduleContentApprovalRequired, JSONArray curriculumPeriodIds) {
        this.metadata = metadata;
        this.code = code;
        this.groupId = groupId;
        this.name = name;
        this.universityOrgIds = universityOrgIds;
        this.rule = rule;
        this.id = id;
        this.type = type;
        this.documentState = documentState;
        this.contentFilter = contentFilter;
        this.moduleContentApprovalRequired = moduleContentApprovalRequired;
        this.curriculumPeriodIds = curriculumPeriodIds;
    }

    public JSONObject getMetadata() {
        return metadata;
    }

    public void setMetadata(JSONObject metadata) {
        this.metadata = metadata;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public JSONObject getName() {
        return name;
    }

    public void setName(JSONObject name) {
        this.name = name;
    }

    public JSONArray getUniversityOrgIds() {
        return universityOrgIds;
    }

    public void setUniversityOrgIds(JSONArray universityOrgIds) {
        this.universityOrgIds = universityOrgIds;
    }

    public JSONObject getRule() {
        return rule;
    }

    public void setRule(JSONObject rule) {
        this.rule = rule;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDocumentState() {
        return documentState;
    }

    public void setDocumentState(String documentState) {
        this.documentState = documentState;
    }

    public JSONObject getContentFilter() {
        return contentFilter;
    }

    public void setContentFilter(JSONObject contentFilter) {
        this.contentFilter = contentFilter;
    }

    public boolean isModuleContentApprovalRequired() {
        return moduleContentApprovalRequired;
    }

    public void setModuleContentApprovalRequired(boolean moduleContentApprovalRequired) {
        this.moduleContentApprovalRequired = moduleContentApprovalRequired;
    }

    public JSONArray getCurriculumPeriodIds() {
        return curriculumPeriodIds;
    }

    public void setCurriculumPeriodIds(JSONArray curriculumPeriodIds) {
        this.curriculumPeriodIds = curriculumPeriodIds;
    }

}
