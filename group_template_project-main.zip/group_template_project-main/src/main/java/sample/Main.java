package sample;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class Main extends Application {

    //for debug
    public static List<Employee> employees = Arrays.<Employee>asList(
            new Employee("Ethan Williams", "Sales Department Sales Department Sales Department Sales Department"),
            new Employee("Emma Jones", "Sales Department"),
            new Employee("Michael Brown", "Sales Department"),
            new Employee("Anna Black", "Sales Department"),
            new Employee("Rodger York", "Sales Department"),
            new Employee("Susan Collins", "Sales Department"),
            new Employee("Mike Graham", "IT Support"),
            new Employee("Judy Mayer", "IT Support"),
            new Employee("Gregory Smith", "IT Support"),
            new Employee("Jacob Smith", "Accounts Department"),
            new Employee("Isabella Johnson", "Accounts Department"));

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
//        FXMLLoader loader = new FXMLLoader();
//
//        Parent root = loader.load(
//                getClass().getResourceAsStream("start.fxml")
//        );

        primaryStage.setTitle("SISU");

        primaryStage.setScene(
                new Scene(
                        new StackPane(),
                        640,
                        480
                )
        );

        String[] userInfo = dialog();

        if(userInfo.length > 0){
//            ReadJsonFile.start();

         mainView(primaryStage, userInfo);
        }
    }

    public static String[] dialog(){
        Dialog<String[]> dialog = new Dialog<>();

        dialog.setTitle("Login");

        dialog.setHeaderText("Please, enter your login informations");

//        Set the icon (must be included in the project).
//        dialog.setGraphic(new ImageView(this.getClass().getResource("login.png").toString()));

        ButtonType loginButtonType =
                new ButtonType(
                        "Login",
                        ButtonBar.ButtonData.OK_DONE
                );

        dialog.getDialogPane().getButtonTypes().addAll(
                loginButtonType,
                ButtonType.CANCEL
        );

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(
                new Insets(
                        20,
                        150,
                        10,
                        10
                )
        );

        TextField username = new TextField();
        username.setPromptText("Username");

        PasswordField password = new PasswordField();
        password.setPromptText("Student Number");

        DatePicker datePicker = new DatePicker();

        grid.add(new Label("Username:"), 0, 0);
        grid.add(username, 1, 0);

        grid.add(new Label("Student Number:"), 0, 1);
        grid.add(password, 1, 1);

        grid.add(new Label("Date"), 0, 2);
        grid.add(datePicker, 1, 2);

        Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);

        loginButton.setDisable(true);

        username.textProperty().addListener((
                observable,
                oldValue,
                newValue) -> {
            loginButton.setDisable(
                    newValue.trim().isEmpty()
            );
        });

        dialog.getDialogPane().setContent(grid);

        Platform.runLater(username::requestFocus);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new String[]{
                        username.getText(),
                        password.getText(),
                        datePicker.getValue().toString()
                };
            }

            return null;
        });

        Optional<String[]> result = dialog.showAndWait();

        return result.orElseGet(() -> new String[]{});
    }

    public static void mainView(Stage primaryStage, String[] userInfo){
        GridPane grid = new GridPane();

        grid.setHgap(100);
        grid.setVgap(100);

        grid.setPadding(
                new Insets(
                        20,
                        150,
                        10,
                        10
                )
        );

        grid.add(
                treeView(primaryStage),
                0,
                0
        );

        grid.add(progressbar(),
                1,
                0
        );

        grid.add(
                new TextField(""+userInfo[0]),
                2,
                0
        );

        VBox box = new VBox();

        final Scene scene = new Scene(
                box,
                640,
                480
        );

        scene.setFill(Color.LIGHTGRAY);

        primaryStage.setScene(scene);

        box.getChildren().add(grid);

        primaryStage.show();
    }

    public static Node treeView(Stage primaryStage){

        TreeItem<String> moduleTreeItem = moduleTreeItem();

        moduleTreeItem.setExpanded(true);

        for (Employee employee : employees) {
            TreeItem<String> i_treeItem = new TreeItem<>(employee.getName());

            boolean found = false;

            for (TreeItem<String> j_treeItem : moduleTreeItem.getChildren()) {

                if (j_treeItem.getValue().contentEquals(employee.getDepartment())){
                    j_treeItem.getChildren().add(i_treeItem);

                    found = true;

                    break;
                }

            }

            if (!found) {
                TreeItem<String> depNode = new TreeItem<String>(
                        employee.getDepartment()
//                        new ImageView(depIcon())
                );

                moduleTreeItem.getChildren().add(depNode);
                depNode.getChildren().add(i_treeItem);
            }
        }

        return new TreeView<>(moduleTreeItem);
    }

    public static Node progressbar(){
        ProgressBar progressBar = new ProgressBar(0);

        progressBar.setProgress(0.7);

        return progressBar;
    }

    @Override
    public void stop() throws Exception {
        System.out.println("ending do some action");

        super.stop();
    }

    //    public static Node rootIcon(){
//        //return new ImageView(new Image(Main.class.getResourceAsStream("root.png")));
//    }

    public static TreeItem<String> moduleTreeItem(){
        return new TreeItem<>("Geographie");
    }

//    public static Image depIcon(){
////        return new Image(Main.class.getResourceAsStream("folder_16.png"));
//    }

    public static class Employee {

        private final SimpleStringProperty name;
        private final SimpleStringProperty department;

        private Employee(String name, String department) {
            this.name = new SimpleStringProperty(name);
            this.department = new SimpleStringProperty(department);
        }

        public String getName() {
            return name.get();
        }

        public void setName(String fName) {
            name.set(fName);
        }

        public String getDepartment() {
            return department.get();
        }

        public void setDepartment(String fName) {
            department.set(fName);
        }
    }

}
