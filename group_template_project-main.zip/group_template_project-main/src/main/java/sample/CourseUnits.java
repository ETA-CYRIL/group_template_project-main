package sample;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class CourseUnits {

    public JSONObject learningMaterial;
    public JSONArray possibleAttainmentLanguages;
    public JSONObject metadata;
    public String code;
    public String subject;
    public String cefrLevel;
    public String groupId;
    public JSONObject additional;
    public JSONArray searchTags;
    public JSONArray universityOrgIds;
    public String studyLevel;
    public JSONObject content;
    public JSONObject validityPeriod;
    public JSONObject prerequisites;
    public JSONArray categoryTags;
    public JSONArray literature;
    public JSONArray compulsoryFormalPrerequisites;
    public JSONArray substitutions;
    public JSONArray organisations;
    public JSONObject equivalentCoursesInfo;
    public JSONObject credits;
    public JSONObject outcomes;
    public JSONArray assessmentItemOrder;
    public String tweetText;
    public String courseUnitType;
    public String id;
    public JSONArray studyFields;
    public String cooperationNetworkStatus;
    public JSONArray recommendedFormalPrerequisites;
    public String inclusionApplicationInstruction;
    public String approvalState;
    public JSONArray completionMethods;
    public String abbreviation;
    public String documentState;
    public JSONObject customCodeUrns;
    public JSONArray responsibilityInfos;
    public JSONObject name;
    public String gradeScaleId;
    public String cooperationNetworkIds;
    public JSONArray curriculumPeriodIds;

    public CourseUnits(JSONObject learningMaterial, JSONArray possibleAttainmentLanguages, JSONObject metadata, String code, String subject, String cefrLevel, String groupId, JSONObject additional, JSONArray searchTags, JSONArray universityOrgIds, String studyLevel, JSONObject content, JSONObject validityPeriod, JSONObject prerequisites, JSONArray categoryTags, JSONArray literature, JSONArray compulsoryFormalPrerequisites, JSONArray substitutions, JSONArray organisations, JSONObject equivalentCoursesInfo, JSONObject credits, JSONObject outcomes, JSONArray assessmentItemOrder, String tweetText, String courseUnitType, String id, JSONArray studyFields, String cooperationNetworkStatus, JSONArray recommendedFormalPrerequisites, String inclusionApplicationInstruction, String approvalState, JSONArray completionMethods, String abbreviation, String documentState, JSONObject customCodeUrns, JSONArray responsibilityInfos, JSONObject name, String gradeScaleId, String cooperationNetworkIds, JSONArray curriculumPeriodIds) {
        this.learningMaterial = learningMaterial;
        this.possibleAttainmentLanguages = possibleAttainmentLanguages;
        this.metadata = metadata;
        this.code = code;
        this.subject = subject;
        this.cefrLevel = cefrLevel;
        this.groupId = groupId;
        this.additional = additional;
        this.searchTags = searchTags;
        this.universityOrgIds = universityOrgIds;
        this.studyLevel = studyLevel;
        this.content = content;
        this.validityPeriod = validityPeriod;
        this.prerequisites = prerequisites;
        this.categoryTags = categoryTags;
        this.literature = literature;
        this.compulsoryFormalPrerequisites = compulsoryFormalPrerequisites;
        this.substitutions = substitutions;
        this.organisations = organisations;
        this.equivalentCoursesInfo = equivalentCoursesInfo;
        this.credits = credits;
        this.outcomes = outcomes;
        this.assessmentItemOrder = assessmentItemOrder;
        this.tweetText = tweetText;
        this.courseUnitType = courseUnitType;
        this.id = id;
        this.studyFields = studyFields;
        this.cooperationNetworkStatus = cooperationNetworkStatus;
        this.recommendedFormalPrerequisites = recommendedFormalPrerequisites;
        this.inclusionApplicationInstruction = inclusionApplicationInstruction;
        this.approvalState = approvalState;
        this.completionMethods = completionMethods;
        this.abbreviation = abbreviation;
        this.documentState = documentState;
        this.customCodeUrns = customCodeUrns;
        this.responsibilityInfos = responsibilityInfos;
        this.name = name;
        this.gradeScaleId = gradeScaleId;
        this.cooperationNetworkIds = cooperationNetworkIds;
        this.curriculumPeriodIds = curriculumPeriodIds;
    }

    public JSONObject getLearningMaterial() {
        return learningMaterial;
    }

    public void setLearningMaterial(JSONObject learningMaterial) {
        this.learningMaterial = learningMaterial;
    }

    public JSONArray getPossibleAttainmentLanguages() {
        return possibleAttainmentLanguages;
    }

    public void setPossibleAttainmentLanguages(JSONArray possibleAttainmentLanguages) {
        this.possibleAttainmentLanguages = possibleAttainmentLanguages;
    }

    public JSONObject getMetadata() {
        return metadata;
    }

    public void setMetadata(JSONObject metadata) {
        this.metadata = metadata;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getCefrLevel() {
        return cefrLevel;
    }

    public void setCefrLevel(String cefrLevel) {
        this.cefrLevel = cefrLevel;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public JSONObject getAdditional() {
        return additional;
    }

    public void setAdditional(JSONObject additional) {
        this.additional = additional;
    }

    public JSONArray getSearchTags() {
        return searchTags;
    }

    public void setSearchTags(JSONArray searchTags) {
        this.searchTags = searchTags;
    }

    public JSONArray getUniversityOrgIds() {
        return universityOrgIds;
    }

    public void setUniversityOrgIds(JSONArray universityOrgIds) {
        this.universityOrgIds = universityOrgIds;
    }

    public String getStudyLevel() {
        return studyLevel;
    }

    public void setStudyLevel(String studyLevel) {
        this.studyLevel = studyLevel;
    }

    public JSONObject getContent() {
        return content;
    }

    public void setContent(JSONObject content) {
        this.content = content;
    }

    public JSONObject getValidityPeriod() {
        return validityPeriod;
    }

    public void setValidityPeriod(JSONObject validityPeriod) {
        this.validityPeriod = validityPeriod;
    }

    public JSONObject getPrerequisites() {
        return prerequisites;
    }

    public void setPrerequisites(JSONObject prerequisites) {
        this.prerequisites = prerequisites;
    }

    public JSONArray getCategoryTags() {
        return categoryTags;
    }

    public void setCategoryTags(JSONArray categoryTags) {
        this.categoryTags = categoryTags;
    }

    public JSONArray getLiterature() {
        return literature;
    }

    public void setLiterature(JSONArray literature) {
        this.literature = literature;
    }

    public JSONArray getCompulsoryFormalPrerequisites() {
        return compulsoryFormalPrerequisites;
    }

    public void setCompulsoryFormalPrerequisites(JSONArray compulsoryFormalPrerequisites) {
        this.compulsoryFormalPrerequisites = compulsoryFormalPrerequisites;
    }

    public JSONArray getSubstitutions() {
        return substitutions;
    }

    public void setSubstitutions(JSONArray substitutions) {
        this.substitutions = substitutions;
    }

    public JSONArray getOrganisations() {
        return organisations;
    }

    public void setOrganisations(JSONArray organisations) {
        this.organisations = organisations;
    }

    public JSONObject getEquivalentCoursesInfo() {
        return equivalentCoursesInfo;
    }

    public void setEquivalentCoursesInfo(JSONObject equivalentCoursesInfo) {
        this.equivalentCoursesInfo = equivalentCoursesInfo;
    }

    public JSONObject getCredits() {
        return credits;
    }

    public void setCredits(JSONObject credits) {
        this.credits = credits;
    }

    public JSONObject getOutcomes() {
        return outcomes;
    }

    public void setOutcomes(JSONObject outcomes) {
        this.outcomes = outcomes;
    }

    public JSONArray getAssessmentItemOrder() {
        return assessmentItemOrder;
    }

    public void setAssessmentItemOrder(JSONArray assessmentItemOrder) {
        this.assessmentItemOrder = assessmentItemOrder;
    }

    public String getTweetText() {
        return tweetText;
    }

    public void setTweetText(String tweetText) {
        this.tweetText = tweetText;
    }

    public String getCourseUnitType() {
        return courseUnitType;
    }

    public void setCourseUnitType(String courseUnitType) {
        this.courseUnitType = courseUnitType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public JSONArray getStudyFields() {
        return studyFields;
    }

    public void setStudyFields(JSONArray studyFields) {
        this.studyFields = studyFields;
    }

    public String getCooperationNetworkStatus() {
        return cooperationNetworkStatus;
    }

    public void setCooperationNetworkStatus(String cooperationNetworkStatus) {
        this.cooperationNetworkStatus = cooperationNetworkStatus;
    }

    public JSONArray getRecommendedFormalPrerequisites() {
        return recommendedFormalPrerequisites;
    }

    public void setRecommendedFormalPrerequisites(JSONArray recommendedFormalPrerequisites) {
        this.recommendedFormalPrerequisites = recommendedFormalPrerequisites;
    }

    public String getInclusionApplicationInstruction() {
        return inclusionApplicationInstruction;
    }

    public void setInclusionApplicationInstruction(String inclusionApplicationInstruction) {
        this.inclusionApplicationInstruction = inclusionApplicationInstruction;
    }

    public String getApprovalState() {
        return approvalState;
    }

    public void setApprovalState(String approvalState) {
        this.approvalState = approvalState;
    }

    public JSONArray getCompletionMethods() {
        return completionMethods;
    }

    public void setCompletionMethods(JSONArray completionMethods) {
        this.completionMethods = completionMethods;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getDocumentState() {
        return documentState;
    }

    public void setDocumentState(String documentState) {
        this.documentState = documentState;
    }

    public JSONObject getCustomCodeUrns() {
        return customCodeUrns;
    }

    public void setCustomCodeUrns(JSONObject customCodeUrns) {
        this.customCodeUrns = customCodeUrns;
    }

    public JSONArray getResponsibilityInfos() {
        return responsibilityInfos;
    }

    public void setResponsibilityInfos(JSONArray responsibilityInfos) {
        this.responsibilityInfos = responsibilityInfos;
    }

    public JSONObject getName() {
        return name;
    }

    public void setName(JSONObject name) {
        this.name = name;
    }

    public String getGradeScaleId() {
        return gradeScaleId;
    }

    public void setGradeScaleId(String gradeScaleId) {
        this.gradeScaleId = gradeScaleId;
    }

    public String getCooperationNetworkIds() {
        return cooperationNetworkIds;
    }

    public void setCooperationNetworkIds(String cooperationNetworkIds) {
        this.cooperationNetworkIds = cooperationNetworkIds;
    }

    public JSONArray getCurriculumPeriodIds() {
        return curriculumPeriodIds;
    }

    public void setCurriculumPeriodIds(JSONArray curriculumPeriodIds) {
        this.curriculumPeriodIds = curriculumPeriodIds;
    }

}
