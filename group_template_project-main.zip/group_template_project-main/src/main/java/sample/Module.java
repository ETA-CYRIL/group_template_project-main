package sample;

public interface Module {

}
