package sample;

public class CourseUnitRule {

    public String courseUnitGroupId;
    public String type;
    public String localId;

    public CourseUnitRule(String courseUnitGroupId, String type, String localId) {
        this.courseUnitGroupId = courseUnitGroupId;
        this.type = type;
        this.localId = localId;
    }

    public String getCourseUnitGroupId() {
        return courseUnitGroupId;
    }

    public void setCourseUnitGroupId(String courseUnitGroupId) {
        this.courseUnitGroupId = courseUnitGroupId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLocalId() {
        return localId;
    }

    public void setLocalId(String localId) {
        this.localId = localId;
    }

}
